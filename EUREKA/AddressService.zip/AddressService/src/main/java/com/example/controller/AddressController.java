/**
 * 
 */
package com.example.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Dongala.Reddy
 *
 */
@RestController
@RequestMapping("/Address")
public class AddressController {

	@GetMapping("/persist")
	public void persistAddress() {
		System.out.println("PERSIST HERE");
	}
}
